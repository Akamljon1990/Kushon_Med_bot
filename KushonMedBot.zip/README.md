# Kushon Medical Servis Telegram Bot
Ushbu bot foydalanuvchilarni /start buyrug‘i orqali kutib oladi.