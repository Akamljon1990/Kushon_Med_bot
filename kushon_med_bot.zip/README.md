# Kushon Medical Servis Telegram Bot

Bu bot Kushon Med laboratoriyasi uchun tayyorlangan. 
/start buyrug'i orqali foydalanuvchini kutib oladi.
